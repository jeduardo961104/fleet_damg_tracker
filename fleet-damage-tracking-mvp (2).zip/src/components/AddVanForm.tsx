import React, { useState } from 'react';
import { Van } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface AddVanFormProps {
  onSubmit: (van: Van) => void;
  onCancel: () => void;
}

export const AddVanForm: React.FC<AddVanFormProps> = ({ onSubmit, onCancel }) => {
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    vanNumber: '',
    vanType: '',
    vin: '',
    plate: '',
    registrationExp: '',
    assetStatus: 'Active',
    mileage: 0,
    operationalStatus: 'Active' as 'Active' | 'Maintenance' | 'Out of Service',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData as Van);
  };

  const statusOptions = [
    { value: 'Active', label: t('active') },
    { value: 'Maintenance', label: t('maintenance') },
    { value: 'Out of Service', label: t('outOfService') },
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('vanNumber')} *
          </label>
          <input
            required
            type="text"
            value={formData.vanNumber}
            onChange={(e) => setFormData({ ...formData, vanNumber: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF9900] focus:border-transparent"
            placeholder="AMZ-001"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('plate')} *
          </label>
          <input
            required
            type="text"
            value={formData.plate}
            onChange={(e) => setFormData({ ...formData, plate: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF9900] focus:border-transparent"
            placeholder={t('plateNumberPlaceholder')}
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          {t('vanType')} *
        </label>
        <input
          required
          type="text"
          value={formData.vanType}
          onChange={(e) => setFormData({ ...formData, vanType: e.target.value })}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF9900] focus:border-transparent"
          placeholder={t('modelPlaceholder')}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          {t('vin')} *
        </label>
        <input
          required
          type="text"
          value={formData.vin}
          onChange={(e) => setFormData({ ...formData, vin: e.target.value })}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF9900] focus:border-transparent"
          placeholder="1FTBW2CM5HKA12345"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('mileage')} *
          </label>
          <input
            required
            type="number"
            min="0"
            value={formData.mileage}
            onChange={(e) => setFormData({ ...formData, mileage: parseInt(e.target.value) })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF9900] focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('registrationExp')}
          </label>
          <input
            type="date"
            value={formData.registrationExp}
            onChange={(e) => setFormData({ ...formData, registrationExp: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF9900] focus:border-transparent"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          {t('operationalStatus')} *
        </label>
        <select
          required
          value={formData.operationalStatus}
          onChange={(e) => setFormData({ ...formData, operationalStatus: e.target.value as 'Active' | 'Maintenance' | 'Out of Service' })}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF9900] focus:border-transparent"
        >
          {statusOptions.map(option => (
            <option key={option.value} value={option.value}>{option.label}</option>
          ))}
        </select>
      </div>

      <div className="flex gap-3 pt-4">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
        >
          {t('cancel')}
        </button>
        <button
          type="submit"
          className="flex-1 px-6 py-3 bg-[#FF9900] text-white rounded-lg hover:bg-[#ec8b00] transition-colors font-medium"
        >
          {t('addVanButton')}
        </button>
      </div>
    </form>
  );
};
