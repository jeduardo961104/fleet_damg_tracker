import React from 'react';
import { Van, DamageReport } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface VanListProps {
  vans: Van[];
  damages: DamageReport[];
  onRemove: (id: string) => void;
  onViewDamages: (vanNumber: string) => void;
}

export const VanList: React.FC<VanListProps> = ({ vans, damages, onRemove, onViewDamages }) => {
  const { t } = useLanguage();

  const getActiveDamages = (vanNumber: string) => {
    return damages.filter(d => d.vanNumber === vanNumber && d.status !== 'Repaired').length;
  };

  const statusColors: Record<string, string> = {
    'Active': 'bg-green-100 text-green-800',
    'Maintenance': 'bg-yellow-100 text-yellow-800',
    'Out of Service': 'bg-red-100 text-red-800',
  };

  const statusLabels: Record<string, string> = {
    'Active': t('active'),
    'Maintenance': t('maintenance'),
    'Out of Service': t('outOfService'),
  };

  if (vans.length === 0) {
    return (
      <div className="text-center py-20 bg-white rounded-xl shadow-sm border border-gray-100">
        <p className="text-gray-500">{t('noVans')}</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {t('vanNumber')}
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {t('vanType')} / {t('plate')}
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {t('vin')}
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {t('mileage')}
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {t('operationalStatus')}
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {t('activeDamages')}
              </th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Acciones
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {vans.map((van) => {
              const activeDamages = getActiveDamages(van.vanNumber);
              return (
                <tr key={van.vanNumber} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-bold text-gray-900">{van.vanNumber}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{van.vanType}</div>
                    <div className="text-sm text-gray-500">{van.plate}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-xs font-mono text-gray-500 bg-gray-50 px-2 py-1 rounded inline-block">
                      {van.vin}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {van.mileage.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColors[van.operationalStatus]}`}>
                      {statusLabels[van.operationalStatus] || van.operationalStatus}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {activeDamages > 0 ? (
                      <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                        {activeDamages}
                      </span>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => onViewDamages(van.vanNumber)}
                      className="text-[#FF9900] hover:text-[#ec8b00] mr-4"
                    >
                      {t('viewDamages')}
                    </button>
                    <button
                      onClick={() => onRemove(van.vanNumber)}
                      className="text-red-600 hover:text-red-900"
                    >
                      {t('removeVan')}
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
