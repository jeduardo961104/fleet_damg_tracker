export const GOOGLE_SHEETS_CONFIG = {
  spreadsheetId: '1ifcppKsFeJ3VUeOe8_RAJxJ_3Iq5FsJYJKVT8suNt2U',
  apiKey: 'AIzaSyAcZepEk6-Kyh6kNRMgNb1VNHeLKGkZ2Nk',
  sheetName: 'Sheet1',
};
